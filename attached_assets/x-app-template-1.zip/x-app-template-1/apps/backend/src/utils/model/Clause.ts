export interface Clause {
  to: string | null;
  value: string;
  data: string;
}
