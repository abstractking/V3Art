export const DISCORD_URL = "https://www.discord.gg/vechain";
export const TELEGRAM_URL = "https://t.me/vechainandfriends";
export const X_TWITTER_URL = "https://x.com/vechainofficial";
export const FACEBOOK_URL = "https://www.facebook.com/vechainOfficial/";
export const EMAIL_URL = "mailto:press@vechain.org";
export const TIKTOK_URL = "https://tiktok.com/@vechain_official";
export const YOUTUBE_URL = "https://www.youtube.com/@vechainofficial";
export const INSTAGRAM_URL = "https://instagram.com/vechainofficial_";
export const LINKEDIN_URL =
  "https://www.linkedin.com/company/vechain-foundation/";

export const PRIVACY_POLICY_LINK = "https://www.vechain.org/privacy-policy/";
export const TERMS_AND_CONDITIONS_LINK =
  "https://www.vechain.org/terms-of-use/";
