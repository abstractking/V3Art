export const backendURL = "http://localhost:3000"; // TODO change to your backend URL
