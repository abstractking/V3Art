export interface ReceiptData {
  image: string;
  address: string;
  deviceID: string;
}
